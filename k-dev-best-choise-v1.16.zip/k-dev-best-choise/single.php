<?php 
get_header();
if(have_posts()): while (have_posts()) : the_post(); ?>
<article class='kdbc-post'>
	<header><?php the_title(''); ?> </header>
	<div class='kdbc-content'>
		<?php the_content(''); ?>
	</div>
	<footer>
		<a href='<?php the_permalink(''); ?>'>Continew.. </a>
	</footer>
</article>
<?php  endwhile; endif;
get_footer();
?>