<?php 
get_header();
?>
<div class='container-fluid'>
	<div class='row justify-content-center w-100 m-0'>
		<div class='col-md-2'></div>
		<div class='col'>
			<h3 class='text-center mt-3' >صفحه‌ای که دنبال آن بودید پیدا نشد!</h3>
			<a class="btn btn-success m-auto d-block w-50 mt-2 mb-3" href='<?php echo site_url(); ?>' rel='nofollow'>صفحه اصلی</a>
			<div class='row w-100 m-auto'>
				<div class='col'>
					<img class='d-block w-75 m-auto' src="<?php echo get_template_directory_uri()."/img/404.png"; ?>" alt='404' />
					</div>
				</div>
			</div>
		<div class='col-md-2'></div>
	</div>
</div>
<?php
get_footer();
?>