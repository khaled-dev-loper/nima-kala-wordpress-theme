function kdbc_show_hide_about_us(is_have_full){
	let __kdbc_add_hover_full_in_show_more_of_abut = "";
	if(is_have_full == true){
		__kdbc_add_hover_full_in_show_more_of_abut = "-full";
	}
	
	var kdbc_show_more = document.getElementById('kdbc_show_more');var kdbc_about_us = document.getElementById('kdbc_about_us'); kdbc_about_us.classList.toggle('kdbc-footer-about-us-hover'+__kdbc_add_hover_full_in_show_more_of_abut); kdbc_about_us.classList.toggle('text-truncate'); if(eval(kdbc_show_more.getAttribute('data-show-more')) == 0){kdbc_show_more.setAttribute('data-show-more','1'); kdbc_show_more.innerText = 'نمایش کمتر'; }else{kdbc_show_more.setAttribute('data-show-more','0'); kdbc_show_more.innerText = 'نمایش بیشتر'; }
}