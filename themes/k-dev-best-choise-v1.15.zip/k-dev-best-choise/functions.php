<?php 
	//run funcs
	kdbc_check_for_update_github();
	//code
	function kdbc_check_for_update_github(){
		$js = file_get_contents("https://raw.githubusercontent.com/khaled-dev-loper/nima-kala-wordpress-theme/main/data.json");
		$js = json_decode($js,true);
		$theme = wp_get_theme();
		// get version
		if (!empty($theme)){
			$theme_version = $theme->get("Version");
			if($js['version'] != $theme_version){
				add_action( 'admin_notices', 'kdbc_update_notice' );
			}
		}
	}
	function kdbc_update_notice(){
			$js = file_get_contents("https://raw.githubusercontent.com/khaled-dev-loper/nima-kala-wordpress-theme/main/data.json");
			$js = json_decode($js,true);
			$new_version = $js['version'];
			$currect_version = "1.00";
			$theme = wp_get_theme();
			// get currect version
			if (!empty($theme))
				$currect_version = $theme->get("Version");
			
			echo    '<div class="notice notice-warning">
			
						<p>نسخه جدیدی از پوسته <strong>نیما کالا </strong> در دسترس است. <a href="https://github.com/khaled-dev-loper/nima-kala-wordpress-theme"> بروزرسانی دستی</a></p>
						<p> نسخه فعلی: <b>'.$currect_version.'</b></p>
						<p> نسخه جدید: <b>'.$new_version.'</b></p>
						<p><strong>  در حال حاضر امکان بروزرسانی خودکار وجود ندارد.</strong></p>
				    </div>';
	}
	function is_set_option($key){
		$def = "QWERTYUIOPASDFGHJKLIUFHSIDHFISDHFIUSDHFISHDFISUDFISHDIFHUDHFI12381203180391832801238";
		if(get_option($key,$def) == $def){
			return false;
		}else{
			return true;
		}
	}
	add_action( 'wp_enqueue_scripts', 'kdbc_theme_styles' );
	function kdbc_wc_get_gallery_image_html( $attachment_id, $main_image = false,$item_class = "" ) {
	  $flexslider        = (bool) apply_filters( 'woocommerce_single_product_flexslider_enabled', get_theme_support( 'wc-product-gallery-slider' ) );
	  $gallery_thumbnail = wc_get_image_size( 'gallery_thumbnail' );
	  $thumbnail_size    = apply_filters( 'woocommerce_gallery_thumbnail_size', array( $gallery_thumbnail['width'], $gallery_thumbnail['height'] ) );
	  $image_size        = apply_filters( 'woocommerce_gallery_image_size', $flexslider || $main_image ? 'woocommerce_single' : $thumbnail_size );
	  $full_size         = apply_filters( 'woocommerce_gallery_full_size', apply_filters( 'woocommerce_product_thumbnails_large_size', 'full' ) );
	  $thumbnail_src     = wp_get_attachment_image_src( $attachment_id, $thumbnail_size );
	  $full_src          = wp_get_attachment_image_src( $attachment_id, $full_size );
	  $alt_text          = trim( wp_strip_all_tags( get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) );
	  $image             = wp_get_attachment_image(
		$attachment_id,
		$image_size,
		false,
		apply_filters(
		  'woocommerce_gallery_image_html_attachment_image_params',
		  array(
			'title'                   => _wp_specialchars( get_post_field( 'post_title', $attachment_id ), ENT_QUOTES, 'UTF-8', true ),
			'data-caption'            => _wp_specialchars( get_post_field( 'post_excerpt', $attachment_id ), ENT_QUOTES, 'UTF-8', true ),
			'data-src'                => esc_url( $full_src[0] ),
			'data-large_image'        => esc_url( $full_src[0] ),
			'data-large_image_width'  => esc_attr( $full_src[1] ),
			'data-large_image_height' => esc_attr( $full_src[2] ),
			'class'                   => esc_attr( ($main_image ? 'wp-post-image' : '')),
		  ),
		  $attachment_id,
		  $image_size,
		  $main_image
		)
	  );

	  return '<div data-thumb="' . esc_url( $thumbnail_src[0] ) . '" data-thumb-alt="' . esc_attr( $alt_text ) . '" class="woocommerce-product-gallery__image '.$item_class.'">
				<a href="' . esc_url( $full_src[0] ) . '">' . $image . '</a>
			  </div>';
	}
	//add 
	function kdbc_theme_styles(){
		wp_enqueue_style( 'defulat-style', get_stylesheet_uri());
		//Responsive 
		wp_enqueue_style( 'bootstrap',get_template_directory_uri()."/css/bootstrap.css");
		wp_enqueue_style( 'extra-small-device',get_template_directory_uri()."/css/extra-small-device.css");
		wp_enqueue_style( 'small-device',get_template_directory_uri()."/css/small-device.css");
		wp_enqueue_style( 'medium-device',get_template_directory_uri()."/css/medium-device.css");
		wp_enqueue_style( 'large-device',get_template_directory_uri()."/css/large-device.css");
		wp_enqueue_style( 'extra-large-device',get_template_directory_uri()."/css/extra-large-device.css");
		
		wp_enqueue_style( 'swiper-css',get_template_directory_uri()."/css/swiper-bundle.min.css");
		//js
		wp_enqueue_script('kdbc_main',get_template_directory_uri()."/js/kdbc_main.js");
		wp_enqueue_script('swiper-js',get_template_directory_uri()."/js/swiper-bundle.min.js");
	}
	//Change Placeholder Search Form
	add_filter( 'wpex_search_placeholder_text', function() {
		return "جستجو ";
	} );	
?>