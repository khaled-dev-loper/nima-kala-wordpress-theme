<?php 
get_header();?>
<?php
if(have_posts()): while (have_posts()) : the_post(); ?>
<article class='kdbc-post'>
	<header></header>
	<div class='kdbc-content'>
		<?php the_content(''); ?>
	</div>
	<footer>
	</footer>
</article>
<?php  endwhile; endif;
get_footer();
?>