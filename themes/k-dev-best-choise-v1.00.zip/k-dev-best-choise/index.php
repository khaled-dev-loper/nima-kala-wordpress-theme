
<?php 
get_header();
?>

<div class='container-fluid'>
	<div class='row w-100'>
		<!--div class='col-md-2  col-sm-12 col-xs-12 col-lg-2 col-xl-2  sidebar'>
		Sidebar
		</div-->
		<div class='col col-md  col-sm col-xs'>
			<div class='container-fluid'>
				<div class='product-shop'>
					<?php 
						if(is_shop()){
							///Setting Menu
							if ( is_singular( 'product' ) ) {
								woocommerce_content();
							}else{
								//For ANY product archive.
								//Product taxonomy, product search or /shop landing
								if(have_posts()): while (have_posts()) : the_post(); ?>
									<?php the_content(''); ?>
								<?php endwhile; endif; 
							}
						}else{
						
						if(have_posts()): while (have_posts()) : the_post(); ?>
						<article class='kdbc-post'>
							<header><h2><?php the_title(''); ?> </h2></header>
							<div class='kdbc-content'>
								<?php the_content(''); ?>
							</div>
							<footer>
							<?php  if(!is_shop() && !is_product()): ?>
								<a class='btn btn-outline-danger' href='<?php the_permalink(''); ?>' rel='dofollow' >ادامه مطلب</a>
							<?php endif; ?>
							<div class='border-bottom p-10'></div>
							</footer>
						</article>
						<?php  endwhile; endif; ?>
					<?php
}?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
get_footer();
?>