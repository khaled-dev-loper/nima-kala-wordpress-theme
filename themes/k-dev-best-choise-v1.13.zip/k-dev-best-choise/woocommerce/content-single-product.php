<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

/**
 * Hook: woocommerce_before_single_product.
 *
 * @hooked woocommerce_output_all_notices - 10
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'row ', $product ); ?>>
	<div class='col-lg-4 align-items-center margin-auto'>
		<?php
		/**
		 * Hook: woocommerce_before_single_product_summary.
		 *
		 * @hooked woocommerce_show_product_sale_flash - 10
		 * @hooked woocommerce_show_product_images - 20
		 */
		do_action( 'woocommerce_before_single_product_summary' );
		?>
	</div>
	<div class="summary entry-summary col-lg">
		<?php
		/**
		 * Hook: woocommerce_single_product_summary.
		 *
		 * @hooked woocommerce_template_single_title - 5
		 * @hooked woocommerce_template_single_rating - 10
		 * @hooked woocommerce_template_single_price - 10
		 * @hooked woocommerce_template_single_excerpt - 20
		 * @hooked woocommerce_template_single_add_to_cart - 30
		 * @hooked woocommerce_template_single_meta - 40
		 * @hooked woocommerce_template_single_sharing - 50
		 * @hooked WC_Structured_Data::generate_product_data() - 60
		 */
		//do_action( 'woocommerce_single_product_summary' );
		?>
		<div class='row kdbc-description-product'>
			<div class='col-md-8 kdbc-description-right-col'>
				<p class='h5'>
					<?php wc_get_template_part( 'single-product/title' ); ?>
				</p>
				<?php wc_get_template_part('single-product/short','description'); ?>
			</div>
			<div class='col-md-4 kdbc-description-left-col p-tb-5'>
				<div class='p-10'>
					<p class='leaf kdbc-shopper'>
					فروشنده</p>
				</div>
				<a class='no-a' href='<?php echo site_url(); ?> ' rel='nofollow'>
					<div class='kdbc-shopper-block w-100 p-t-20'>
						<div class='row'>
							<div class='col-2'>
								<!--img src='<?php echo get_template_directory_uri()."/img/shop.png"; ?>' alt='store' /-->
								<p class='store-icon'>
								</p>
							</div>
							<div class='col-10'>
								<p class='leaf h6' >
									<?php echo bloginfo("name"); ?>
								</p>
							</div>
						</div>
					</div>
				</a>
				<div class='p-10'>
					<div class='border-bottom'></div>
				</div>
				<?php if ( $product->is_in_stock() ) : ?>
				<div class='kdbc-shopper-block w-100 p-t-20  pos-relative'>
					<div class='row'>
						<div class='col-2'>
							<!--img src='<?php echo get_template_directory_uri()."/img/shop.png"; ?>' alt='store' /-->
							<p class='stock-icon' >
							</p>
						</div>
						<div class='col-10'>
							<p class='leaf h6' >
								موجود در انبار <?php echo bloginfo("name"); ?>
							</p>
						</div>
					</div>
					<div class='row'>
						<div class='col-2'>
							<div class='kdbc-product-circle'></div>
						</div>
						<div class='col-10'>
							<span class='leaf h7 car-store-icon' >
								ارسال  <?php echo bloginfo("name"); ?>
							</span>
						</div>
					</div>
					<div class='kdbc-product-rect'></div>
				</div>
				<?php endif; ?>
				<div class='kdbc-break-line-shop'></div>
				<?php wc_get_template_part('single-product/add-to-cart/simple'); ?>
			</div>
		</div>
	</div>
	<div class='row'>
		<div class='col'>
			<?php
			/**
			 * Hook: woocommerce_after_single_product_summary.
			 *
			 * @hooked woocommerce_output_product_data_tabs - 10
			 * @hooked woocommerce_upsell_display - 15
			 * @hooked woocommerce_output_related_products - 20
			 */
			do_action( 'woocommerce_after_single_product_summary' );
			?>
		</div>
	</div>
</div>


<?php do_action( 'woocommerce_after_single_product' ); ?>
