<!DOCTYPE html>
<?php 
////Theme Variables 
	global $url_logo;
	$url_logo = get_template_directory_uri()."/img/defualt-icon.png";
	if(get_option( 'kdnks_logo' ,"0") != "0"){
		$url_logo = wp_get_attachment_url( get_option( 'kdnks_logo' ) );
	}
?>
<html <?php language_attributes(); ?> dir="rtl">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<script src="<?php echo get_template_directory_uri()."/js/popper.min.js"; ?>" type='text/javascript'></script>
		<script src="<?php echo get_template_directory_uri()."/js/bootstrap.js"; ?>" type='text/javascript'></script>
		<!--Require Scripts -->
		<style name='digikala'>
			@font-face{
				font-family:digikala;
				src:url(<?php echo get_template_directory_uri(); ?>/font/digikala.eot);
				src:url(<?php echo get_template_directory_uri(); ?>/font/digikala.eot?#iefix) format("eot"),url(<?php echo get_template_directory_uri(); ?>/font/digikala.woff2) format("woff2"),url(<?php echo get_template_directory_uri(); ?>/font/digikala.woff) format("woff"),url(<?php echo get_template_directory_uri(); ?>/font/digikala.ttf) format("truetype");
			}
		</style>
		<script type='text/javascript' >
			if (!('remove' in Element.prototype)) {
				Element.prototype.remove = function() {
					if (this.parentNode) {
						this.parentNode.removeChild(this);
					}
				};
			}
		</script>
		<script type='text/javascript'>
		window.addEventListener("load",function(){
		let wc_images = document.getElementsByClassName("woocommerce-product-gallery__image")
		for(let i = 0;i < wc_images.length;i++){
			wc_images[i].classList.add("swiper-slide");
		}
		});
		</script>
		<!--Require Scripts -->
		<title><?php bloginfo( 'name' ); ?></title>
		<?php wp_head(); ?>
		<style name='kdbc-root-style'>
			:root{
				--bg-documnet:#f5f5f5;
			}
		</style>
		<script name='kdbc-remover' type='text/javascript'>
			var ShouldRemove = {}
			ShouldRemove[0] = document.querySelector("style[media=\"screen\"]")
			for(const[key,val] of Object.entries(ShouldRemove)){
				try{
					val.remove()
				}catch{
					//ignore
				}
			}
		</script>
	</head>
	<body <?php body_class(); ?>>
	<?php // Add Loading Bar 
		if(function_exists("kdnk_get") == true){
			$kdnk_site_logo = $url_logo;
			$kdnk_loading_count = kdnk_get("kdnk_circle_count") == null ? 4 : kdnk_get("kdnk_circle_count");
			$kdnk_short_code = "[kdnk_loading_bar count='".$kdnk_loading_count."' logo='$kdnk_site_logo']";
			$kdnk_shortcode = do_shortcode($kdnk_short_code);
			if ($kdnk_shortcode != $kdnk_short_code)
				echo $kdnk_shortcode;
		}
	?>
		<div class='container-fluid kdbc-header'>
			<div class="row align-items-center kdbc-header-row">
			
				<div class='col-md-2 align-self-center'>
					<!-- Logo -->
					<a class='kdbc-logo' href='<?php echo site_url(); ?>' rel='nofollow'>
						<img src="<?php echo $url_logo; ?>" alt='logo' loading='lazy'/>
					</a>
				</div>
				
				<div class='col-md-8 align-self-center kdbc-search-col '>
					<!-- Defulat Form -->
						<?php //  get_product_search_form();  ?> 
					<!-- Customize Form -->
						<form role="search" method="get" class="woocommerce-product-search" action="http://localhost/wordpress/">
							<label class="screen-reader-text" for="woocommerce-product-search-field-0">جستجو محصول</label>
							<input type="search" id="woocommerce-product-search-field-0" class="search-field" placeholder="Search products…" value="" name="s">
							<button type="submit" value="Search">جستجو</button>
							<input type="hidden" name="post_type" value="product">
						</form>
					</div>
				<div class='col-md-2 align-self-center '>
					<a class='cart-icon' href='<?php echo wc_get_cart_url();?>' rel='nofollow'></a>
				</div>
			</div>
			<?php do_shortcode('[kdmm_mega_menu]'); ?>
		</div>