		<footer class='kdbc-footer'>
			<div class='container-fluid'>
				<?php 
					$footer_p1 = "2";
					$footer_p2 = "2";
					$footer_p3 = "2";
					$footer_p4 = "2";
					$kdnks_aboutus_txt = "";
					$kdnks_aboutus_title = "فروشگاه من";
					$copyright_def = "استفاده از مطالب فروشگاه اینترنتی من فقط برای مقاصد غیرتجاری و با ذکر منبع بلامانع است. کلیه حقوق این سایت متعلق به مدیر سایت می‌باشد.";
			
					if(is_set_option("kdnks_footer_p1")){
						$footer_p1 = get_option("kdnks_footer_p1");
					}if(is_set_option("kdnks_footer_p2")){
						$footer_p2 = get_option("kdnks_footer_p2");
					}if(is_set_option("kdnks_footer_p3")){
						$footer_p3 = get_option("kdnks_footer_p3");
					}if(is_set_option("kdnks_footer_p4")){
						$footer_p4 = get_option("kdnks_footer_p4");
					}if(is_set_option("kdnks_aboutus_txt")){
						$kdnks_aboutus_txt = get_option("kdnks_aboutus_txt");
					}if(is_set_option("kdnks_aboutus_title")){
						$kdnks_aboutus_title = get_option("kdnks_aboutus_title");
					}if(is_set_option("kdnks_copyright")){
						$copyright_def = get_option("kdnks_copyright");
					}
					$google_ply = "2";
					$bazzar = "2";
					$mayket = "2";
					$sibapp = "2";
					$social_mendia_count = 0;
					$google_ply_url = "#";
					$bazzar_url = "#";
					$mayket_url = "#";
					$sibapp_url = "#";
					if(is_set_option("application_google_play")){
						$google_ply = get_option("application_google_play");
						$google_ply_url = get_option("application_google_play_txt");
						if($google_ply == "2")
							$social_mendia_count++;
					}
					if(is_set_option("application_bazzar")){
						$bazzar = get_option("application_bazzar");
						$bazzar_url = get_option("application_bazzar_txt");
						if($bazzar == "2")
							$social_mendia_count++;
					}
					if(is_set_option("application_mayket")){
						$mayket = get_option("application_mayket");
						$mayket_url = get_option("application_mayket_txt");
						if($mayket == "2")
							$social_mendia_count++;
					}
					if(is_set_option("application_sibapp")){
						$sibapp = get_option("application_sibapp");
						$sibapp_url = get_option("application_sibapp_txt");
						if($sibapp == "2")
							$social_mendia_count++;
					}
				?>
				<?php if($footer_p1 != "1"): ?>
					<div class='row <?php echo ($footer_p1 == "3" ? "row-reverse" : ""); ?>'>
						<?php if($footer_p1 == "2" || $footer_p1 == "3" || $footer_p1 == "4"): ?>
							<div class='col footer-l1-right-col'>
								<img src="<?php global $url_logo; echo $url_logo; ?>" alt='logo' loading='lazy' />
							</div>
						<?php endif; ?>
						<?php if($footer_p1 == "2" || $footer_p1 == "3" || $footer_p1 == "5" || $footer_p1 == "6"): ?> 
							<div class='col align-self-start footer-l1-left-col <?php echo ($footer_p1 == "5" ? "footer-l1-left-col-center" : ""); ?>'>
								<button type='button' class='btn btn-outline-danger' onclick="javascript:window.scrollTo(0,0);" rel='nofollow'>بازگشت به بالا</Button>
							</div>
					<?php endif; ?>
					</div>
				<?php endif; ?>
				
				<?php if($footer_p2 == "2" || $footer_p2 == "3"): ?>
					<div class='row'>
						<div class='col footer-l2-col<?php echo ($footer_p2 == "3" ? " footer-l2-col-center" : ""); ?>'>
							<p class='footer-l2-p1-col'>تلفن پشتیبانی:
								<p class='footer-l2-p2-col'>&nbsp;021-123-123231&nbsp;</p>
								<p class='footer-l2-p3-col'>&nbsp;|&nbsp;</p>
								<p class='footer-l2-p4-col'>هشت روز هفته پاسخگوی شما عزیزان هستیم.</p>
							</p>
						</div>
					</div>
					<?php endif; ?>
					<?php if($footer_p3 == "2"): ?>
						<div class='row row-cols-2 footer-l3 '>

							<div class='col-md align-self-center footer-l3-p1'>
								<img src='<?php echo get_template_directory_uri()."/img/footer/1.svg"; ?>' alt='img1' loading='lazy' />
								<h6>امکان تحویل اکسپرس</h6>
							</div>
							<div class='col-md align-self-center  footer-l3-p2'>
								<img src='<?php echo get_template_directory_uri()."/img/footer/2.svg"; ?>' alt='img2' loading='lazy' />
								<h6>امکان پرداخت در محل</h6>
							</div>
							<div class='col-md align-self-center  footer-l3-p3'>
								<img src='<?php echo get_template_directory_uri()."/img/footer/3.svg"; ?>' alt='img3' loading='lazy' />
								<h6>7 روز هفته ، 24 ساعته</h6>
							</div>
							<div class='col-md align-self-center  footer-l3-p4'>
								<img src='<?php echo get_template_directory_uri()."/img/footer/4.svg"; ?>' alt='img4' loading='lazy' />
								<h6>7 روز ضمانت بازگشت کالا</h6>
							</div>
							<div class='col-md align-self-center  footer-l3-p5'>
								<img src='<?php echo get_template_directory_uri()."/img/footer/5.svg"; ?>' alt='img5' loading='lazy' />
								<h6>ضمانت اصل بودن کالا</h6>
							</div>
						</div>
					<?php endif; ?>
					<?php if($footer_p4 == "2"): ?>
					<div class='row footer-l4'>
						<div class='col'>
							<h3>اپلیکیشن <?php echo bloginfo("name"); ?></h3>
						</div>
						<div class='col-md-auto'>
							<div class='row row-cols-2 row-cols-sm-2 justify-content-center'>
								<?php if($google_ply == "2"): ?>
								<div class='col-md'>
									<a href='<?php echo $google_ply_url;  ?>' rel='nofollow' >
										<img src='<?php echo get_template_directory_uri()."/img/footer/google-play.svg"; ?>' loading='lazy' alt='google-play' />
									</a>
								</div>
								<?php endif; ?>
								<?php if($bazzar == "2"): ?>
								<div class='col-md'>
								
									<a href='<?php echo $bazzar_url;  ?>' rel='nofollow' >
									<img src='<?php echo get_template_directory_uri()."/img/footer/bazzar.svg"; ?>' loading='lazy' alt='bazzar' />
									</a>
								</div>
								<?php endif; ?>
								<?php if($mayket == "2"): ?>
								<div class='col-md'>
									<a href='<?php echo $mayket_url;  ?>' rel='nofollow' >
										<img src='<?php echo get_template_directory_uri()."/img/footer/mayket.png"; ?>' loading='lazy' alt='mayket' />
									</a>
								</div>
								<?php endif; ?>
								<?php if($sibapp == "2"): ?>
								<div class='col-md'>
									<a href='<?php echo $sibapp_url;  ?>' rel='nofollow' >
										<img src='<?php echo get_template_directory_uri()."/img/footer/sib-app.svg"; ?>' loading='lazy' alt='sib-app' />
									</a>
								</div>
								<?php endif; ?>
								
							</div>
						</div>
					</div>
					<?php endif; ?>
					<div class='row footer-l5' >
						<div class='col'>
							<h6><?php echo $kdnks_aboutus_title; ?></h6>
							<p id='kdbc_about_us' class='text-secondary text-truncate kdbc-footer-about-us-hover-full'>
								<?php echo str_replace("<br />",'&#13;', nl2br( $kdnks_aboutus_txt)); ?>
							</p>
							<?php if(strlen($kdnks_aboutus_txt) > 49): // 49 for Mobile , 79 for Tablet , 139 for Desktop(1366x768) ?>
								<a id='kdbc_show_more' class='text-primary kdbc-show-more lead' data-show-more='0' onclick='javascript:kdbc_show_hide_about_us(true);' >مشاهده بیشتر</a>
							<?php endif; ?>
						</div>
						<!--div class='col-md-4'>ENAMAD</div-->
					</div>
					<div class='row footer-l6 copyright'>
						<p class='text-secondary'>
<?php echo $copyright_def; ?>
						</p>
					</div>
				</div>
		</footer>
	</body>
</html>