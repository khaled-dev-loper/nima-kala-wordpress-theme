<?php 
/*
Plugin Name:    K-Dev Nima kala Settings
Description:    Require Nima Kala Theme
Author:         Khaled Developer
Author URI:     https://aparat.com/khaledsss
Version:        1.0
Text Domain:    kdev-nima-kala-settings
Domain Path:    /lang
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/
function kdnks_add_main_menu(){
	add_menu_page("Nima Kala","Nima Kala","manage_options","k-dev-nima-kala","kdnks_main_menu_content","",6);
}
//add defulat 
function kdnks_add_defulat_options($key,$def){
	if(get_option($key,"-234") == "-234"){
		add_option($key,$def);
	}
}
add_action("admin_menu","kdnks_add_main_menu");
function kdnks_main_menu_content(){
	?>
		<div class='card'>
			<h1>لوگو سایت</h1>
			<?php
				
				if ( isset( $_POST['submit_image_selector'] ) && isset( $_POST['image_attachment_id'] ) ) :
						update_option( 'kdnks_logo', absint( $_POST['image_attachment_id'] ) );
					endif;
					if(isset($_POST['clean_img'])){
						update_option( 'kdnks_logo', "0");
						
					}
					wp_enqueue_media();
					?><form method='post'>
						<div class='image-preview-wrapper'>
							<img id='image-preview' src='<?php echo wp_get_attachment_url( get_option( 'kdnks_logo' ) ); ?>' style='width:100px;'>
						</div>
						<input id="upload_image_button" type="button" class="button" value="انتخاب عکس" />
						<input type='hidden' name='image_attachment_id' id='image_attachment_id' value='<?php echo get_option( 'kdnks_logo' ); ?>'>
						
						<input type="submit" name="submit_image_selector" value="ثبت" class="button-primary">
					</form>
					<br>
					<form method='post'>
						<input type='submit' value='بازگشت به حالت اولیه عکس' name='clean_img' class='button-secondary'/>
						
					</form>
				<?php
				$my_saved_attachment_post_id = get_option( 'kdnks_logo', 0 );
					?>
					<script type='text/javascript'>
						jQuery( document ).ready( function( $ ) {
							// Uploading files
							var file_frame;
							var wp_media_post_id = wp.media.model.settings.post.id; // Store the old id
							var set_to_post_id = <?php echo $my_saved_attachment_post_id; ?>; // Set this
							jQuery('#upload_image_button').on('click', function( event ){
								event.preventDefault();
								// If the media frame already exists, reopen it.
								if ( file_frame ) {
									// Set the post ID to what we want
									file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
									// Open frame
									file_frame.open();
									return;
								} else {
									// Set the wp.media post id so the uploader grabs the ID we want when initialised
									wp.media.model.settings.post.id = set_to_post_id;
								}
								// Create the media frame.
								file_frame = wp.media.frames.file_frame = wp.media({
									title: 'لوگو سایت خود را انتخاب کنید',
									button: {
										text: 'انتخاب',
									},
									multiple: false // Set to true to allow multiple files to be selected
								});
								// When an image is selected, run a callback.
								file_frame.on( 'select', function() {
									// We set multiple to false so only get one image from the uploader
									attachment = file_frame.state().get('selection').first().toJSON();
									// Do something with attachment.id and/or attachment.url here
									$( '#image-preview' ).attr( 'src', attachment.url ).css( 'width', '100px' );
									$( '#image_attachment_id' ).val( attachment.id );
									// Restore the main post ID
									wp.media.model.settings.post.id = wp_media_post_id;
								});
									// Finally, open the modal
									file_frame.open();
							});
							// Restore the main ID when the add media button is pressed
							jQuery( 'a.add_media' ).on( 'click', function() {
								wp.media.model.settings.post.id = wp_media_post_id;
							});
						});
			</script>
		</div>
		<div class="card">
		<?php
			//code
			if(isset($_POST['submit_footer']) && $_POST['submit_footer'] == "ثبت"){
				if (isset($_POST['submit_footer']) && isset($_POST['footer-p1']) && isset($_POST['footer-p2'])){
					update_option("kdnks_footer_p1",$_POST['footer-p1']);
					update_option("kdnks_footer_p2",$_POST['footer-p2']);
					echo "<b>ثبت شد.</b>";
				}
			}else{
				delete_option("kdnks_footer_p1");
				delete_option("kdnks_footer_p2");
			}
			//defulats 
			kdnks_add_defulat_options("kdnks_footer_p1","2");
			kdnks_add_defulat_options("kdnks_footer_p2","3");
			?>
			<form method='post' >	
				<h1>نوع فوتر</h1>
				<h3>بخش اول:</h3>
				<?php 
						
						
						?>
				<img src='<?php echo plugins_url("/img/footer-p1-n1.svg",__FILE__); ?>' alt='footer-p1-n1' style='width:400px;'  loading='lazy' />
				<input type='radio' name='footer-p1' value='1'  <?php echo (get_option("kdnks_footer_p1") == "1" ? "checked" : ""); ?>   />
				<br>
				<img src='<?php echo plugins_url("/img/footer-p1-n2.svg",__FILE__); ?>' alt='footer-p1-n2' style='width:400px;'  loading='lazy' />
				<input type='radio' name='footer-p1' value='2'  <?php echo (get_option("kdnks_footer_p1") == "2" ? "checked" : ""); ?>   />
				<br>
				<img src='<?php echo plugins_url("/img/footer-p1-n3.svg",__FILE__); ?>' alt='footer-p1-n3' style='width:400px;'  loading='lazy' />
				<input type='radio' name='footer-p1' value='3'  <?php echo (get_option("kdnks_footer_p1") == "3" ? "checked" : ""); ?>   />
				<br>
				<img src='<?php echo plugins_url("/img/footer-p1-n4.svg",__FILE__); ?>' alt='footer-p1-n4' style='width:400px;'  loading='lazy' />
				<input type='radio' name='footer-p1' value='4'  <?php echo (get_option("kdnks_footer_p1") == "4" ? "checked" : ""); ?>   />
				<br>
				<img src='<?php echo plugins_url("/img/footer-p1-n5.svg",__FILE__); ?>' alt='footer-p1-n5' style='width:400px;'  loading='lazy' />
				<input type='radio' name='footer-p1' value='5'  <?php echo (get_option("kdnks_footer_p1") == "5" ? "checked" : ""); ?>   />
				<br>
				<img src='<?php echo plugins_url("/img/footer-p1-n6.svg",__FILE__); ?>' alt='footer-p1-n6' style='width:400px;'  loading='lazy' />
				<input type='radio' name='footer-p1' value='6'  <?php echo (get_option("kdnks_footer_p1") == "6" ? "checked" : ""); ?>   />
				<br>
				
				<h3>بخش دوم:</h3>
				<img src='<?php echo plugins_url("/img/footer-p2-n1.svg",__FILE__); ?>' alt='footer-p2-n1' style='width:400px;'  loading='lazy' />
				<input type='radio' name='footer-p2' value='1'  <?php echo (get_option("kdnks_footer_p2") == "1" ? "checked" : ""); ?>   />
				<br>
				<img src='<?php echo plugins_url("/img/footer-p2-n2.svg",__FILE__); ?>' alt='footer-p2-n2' style='width:400px;'  loading='lazy' />
				<input type='radio' name='footer-p2' value='2'  <?php echo (get_option("kdnks_footer_p2") == "2" ? "checked" : ""); ?>   />
				<br>
				<img src='<?php echo plugins_url("/img/footer-p2-n3.svg",__FILE__); ?>' alt='footer-p2-n3' style='width:400px;'  loading='lazy' />
				<input type='radio' name='footer-p2' value='3'  <?php echo (get_option("kdnks_footer_p2") == "3" ? "checked" : ""); ?>   />
				<br>
				<input type="submit" name="submit_footer" value="ثبت" class="button-primary">
				<input type="submit" name="submit_footer" value="بازگشت به حالت اولیه" class="button">
			</form>
		</div>
		<div class='card'>
			<form method='post'>
				<?php 
					if(isset($_POST['submit_fo_settings']) && $_POST['submit_fo_settings'] == 'ثبت'){
						if(isset($_POST['submit_fo_settings'])){
							if(!isset($_POST['footer-p3']) ||( isset($_POST['footer-p3']) && $_POST['footer-p3'] == null)){
								update_option("kdnks_footer_p3","1");
							}else if (isset($_POST['footer-p3']) && $_POST['footer-p3'] == "2"){
								update_option("kdnks_footer_p3","2");
							}
							if(!isset($_POST['footer-p4']) || (isset($_POST['footer-p4']) && $_POST['footer-p4'] == null)){
								update_option("kdnks_footer_p4","1");
							}else if (isset($_POST['footer-p4']) && $_POST['footer-p4'] == "2"){
								update_option("kdnks_footer_p4","2");
							}
							echo "<b>ثبت شد.</b>";
						}
					}else{
						delete_option("kdnks_footer_p3");
						delete_option("kdnks_footer_p4");
					}
					kdnks_add_defulat_options("kdnks_footer_p3","2");
					kdnks_add_defulat_options("kdnks_footer_p4","2");
				?>
				<h2>
					تنظیمات نمایش بخش های فوتر
				</h2>
		
				<label>نمایش بخش اطمینان از خرید:</label>
				<input type='checkbox' name='footer-p3' value='2'  <?php echo (get_option("kdnks_footer_p3") == "2" ? "checked" : ""); ?>   />
				<br>
				<label>نمایش بخش اپلیکیشن:</label>
				<input type='checkbox' name='footer-p4' value='2'  <?php echo (get_option("kdnks_footer_p4") == "2" ? "checked" : ""); ?>   />
				<br>
				<br>
				<input type="submit" name="submit_fo_settings" value="ثبت" class="button-primary">
				<input type="submit" name="submit_fo_settings" value="بازگشت به حالت اولیه" class="button">
			</form>
		</div>
		<div class='card'>
		<?php 
			if(isset($_POST['submit_social_media'])){
				//Show & hide 
				if(!isset($_POST['application-google-ply'])){
					update_option("application_google_play","1");
				}else if(isset($_POST['application-google-ply']) && $_POST['application-google-ply'] == "1"){
					update_option("application_google_play","2");
					$google_play_url = "";
					$google_play_url = $_POST['application-google-ply-txt'] != null ? $_POST['application-google-ply-txt'] : "";
					update_option("application_google_play_txt",$google_play_url);
				}
				if(!isset($_POST['application-bazzar'])){
					update_option("application_bazzar","1");
				}else if(isset($_POST['application-bazzar']) && $_POST['application-bazzar'] != null){
					update_option("application_bazzar","2");
					$bazzar_url = "";
					$bazzar_url = $_POST['application-bazzar-txt'] != null ? $_POST['application-bazzar-txt'] : "";
					update_option("application_bazzar_txt",$bazzar_url);
				}
				if(!isset($_POST['application-mayket'])){
					update_option("application_mayket","1");
				}else if(isset($_POST['application-mayket']) && $_POST['application-mayket'] != null){
					update_option("application_mayket","2");
					$mayket_url = "";
					$mayket_url = $_POST['application-mayket-txt'] != null ? $_POST['application-mayket-txt'] : "";
				
					update_option("application_mayket_txt",$mayket_url);
				}
				if(!isset($_POST['application-sib-app'])){
					update_option("application_sibapp","1");
				}else if(isset($_POST['application-sib-app']) && $_POST['application-sib-app'] != null){
					update_option("application_sibapp","2");
					$sibapp_url = "";
					$sibapp_url = $_POST['application-sib-app-txt'] != null ? $_POST['application-sib-app-txt'] : "";
					update_option("application_sibapp_txt",$sibapp_url);
				}
				echo "<b>ثبت شد.</b>";


			}
			kdnks_add_defulat_options("application_google_play","2");
			kdnks_add_defulat_options("application_bazzar","2");
			kdnks_add_defulat_options("application_mayket","2");
			kdnks_add_defulat_options("application_sibapp","2");
			kdnks_add_defulat_options("application_google_play_txt","#");
			kdnks_add_defulat_options("application_bazzar_txt","#");
			kdnks_add_defulat_options("application_mayket_txt","#");
			kdnks_add_defulat_options("application_sibapp_txt","#");
		?>
			<form method='post'>
				<h2>
					اپلیکیشن
				</h2>
					<label>گوگل پلی:</label>
					<input type='checkbox' onclick="javascript:var app_txt_gogle_ply = document.getElementById('app-txt-google-ply'); app_txt_gogle_ply.disabled = !app_txt_gogle_ply.disabled;" name='application-google-ply' value="1" <?php echo (get_option("application_google_play") == "2" ? "checked" : ""); ?> />
					<br>
					<label>لینک</label>
					<input type='text' id='app-txt-google-ply' value='<?php echo get_option("application_google_play_txt"); ?>' name='application-google-ply-txt' <?php echo (get_option("application_google_play") == "2" ? "" : "disabled"); ?>  />
					<br>
				<br>
				
					<label>بازار:</label>
					<input type='checkbox' onclick="javascript:var app_txt_bazzar = document.getElementById('app-txt-bazzar'); app_txt_bazzar.disabled = !app_txt_bazzar.disabled;" name='application-bazzar' value="1" <?php echo (get_option("application_bazzar") == "2" ? "checked" : ""); ?> />
					<br>
					<label>لینک</label>
					<input type='text' id='app-txt-bazzar' value='<?php echo get_option("application_bazzar_txt"); ?>' name='application-bazzar-txt'   <?php echo (get_option("application_bazzar") == "2" ? "" : "disabled"); ?> />
					<br>
				<br>
				
					<label>مایکت:</label>
					<input type='checkbox' onclick="javascript:var app_txt_mayket = document.getElementById('app-txt-mayket'); app_txt_mayket.disabled = !app_txt_mayket.disabled;" name='application-mayket' value="1" <?php echo (get_option("application_mayket") == "2" ? "checked" : ""); ?> />
					<br>
					<label>لینک</label>
					<input type='text' id='app-txt-mayket' value='<?php echo get_option("application_mayket_txt"); ?>' name='application-mayket-txt'  <?php echo (get_option("application_mayket") == "2" ? "" : "disabled"); ?> />
					<br>
				<br>
				
					<label>سیب آپ:</label>
					<input type='checkbox' onclick="javascript:var app_txt_sib_app = document.getElementById('app-txt-sib-app'); app_txt_sib_app.disabled = !app_txt_sib_app.disabled;" name='application-sib-app' value="1" <?php echo (get_option("application_sibapp") == "2" ? "checked" : ""); ?> />
					<br>
					<label>لینک</label>
					<input type='text' id='app-txt-sib-app' value='<?php echo get_option("application_sibapp_txt"); ?>' name='application-sib-app-txt'  <?php echo (get_option("application_sibapp") == "2" ? "" : "disabled"); ?>  />
					<br>
				<br>
				<br>
				<input type='submit' name='submit_social_media' value='ثبت' class='button-primary' />
			</form>
			
		</div>
		<?php 
		if(isset($_POST['submit_about_us']) && $_POST['submit_about_us'] == "ثبت"){
			update_option("kdnks_aboutus_title",$_POST['kdbc_aboutus_title']);
			update_option("kdnks_aboutus_txt",$_POST['kdbc_aboutus_txt']);
			echo "<b>ثبت شد.</b>";
		}else if (isset($_POST['submit_about_us']) && $_POST['submit_about_us'] != "ثبت"){
			delete_option("kdnks_aboutus_title");
			delete_option("kdnks_aboutus_txt");
		}
			kdnks_add_defulat_options("kdnks_aboutus_title","فروشگاه اینترنتی ‌من، بررسی، انتخاب و خرید آنلاین");
			kdnks_add_defulat_options("kdnks_aboutus_txt","از اینکه قالب بینظیر نیما کالا را نصب کرده اید سپاسگذاریم.در این قالب تمام بخش ها قابل ویرایش میباشد حتی این متن که شما دارید انرا میخوانید. عجله کنید ، تغییرات خود را اعمال کنید و بیزینس خود را راه اندازی کنید.");
		?>
		<div class='card' style='max-width:unset; width:1000px;'>
			<h2> درباره ما </h2>
			<form method='post'>
			<label>سرتیتر درباره ما</label>
			<br>
			<input type='text' name='kdbc_aboutus_title' value="<?php echo get_option("kdnks_aboutus_title"); ?>"  style='width:100%;'/>
			
			<br>
			<br>
			<label>متن درباره ما:</label>
			<br>
			
			<textarea name='kdbc_aboutus_txt' style='width:100%; min-width:400px; max-width:70vw; resize:both; min-height:300px;' ><?php echo get_option('kdnks_aboutus_txt'); ?></textarea>
			<br>
			<input  type='submit' name='submit_about_us' value='ثبت' class='button-primary' />
			<input  type='submit' name='submit_about_us' value='بازگشت به حالت اولیه' class='button' />
			</form>
		</div>
		<div class='card' style='max-width:unset; width:1000px;'>
		<?php 
			if(isset($_POST['submit_copyright']) && $_POST['submit_copyright'] == "ثبت"){
				update_option("kdnks_copyright",$_POST['kdbc_copyright']);
			}else if (isset($_POST['submit_copyright']) && $_POST['submit_copyright'] != "ثبت"){
				delete_option("kdnks_copyright");
			}
			$copyright_def = "استفاده از مطالب فروشگاه اینترنتی من فقط برای مقاصد غیرتجاری و با ذکر منبع بلامانع است. کلیه حقوق این سایت متعلق به مدیر سایت می‌باشد.";
			kdnks_add_defulat_options("kdnks_copyright",$copyright_def);
		?>
			<form method='post'>
			<h2>قانون کپی رایت</h2>
				<label>متن قانون کپی رایت :</label>
				<input type='text' name='kdbc_copyright' value='<?php echo get_option("kdnks_copyright"); ?>' style='width:100%;' />
				<br>
				<br>
				<input  type='submit' name='submit_copyright' value='ثبت' class='button-primary' />
				<input  type='submit' name='submit_copyright' value='بازگشت به حالت اولیه' class='button' />
			</form>
		</div>
	<?php
}

?>
