<?php 
/*
Plugin Name:    K-Dev Mega Menu
Description:    create Mega menu , you can use with a little shortcode [kdmm_mega_menu]
Author:         Khaled Developer
Author URI:     https://aparat.com/khaledsss
Version:        1.0
Text Domain:    kdev-mega-menu
Domain Path:    /lang
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/ 
function kdmm_register_my_menus(){
register_nav_menus(
	array('kdmm_main_menu'=> "[K-Dev Mega Menu]Main Menu",
		  'kdmm_cols' => "[K-Dev Mega Menu]Columnes",
		  'kdmm_data1_col1' => "[K-Dev Mega Menu]Left Data (Col 1)",
		  'kdmm_data2_col1' => "[K-Dev Mega Menu]Center Data (Col 1)",
		  'kdmm_data3_col1' => "[K-Dev Mega Menu]Right Data (Col 1)",
		  'kdmm_data1_col2' => "[K-Dev Mega Menu]Left Data (Col 2)",
		  'kdmm_data2_col2' => "[K-Dev Mega Menu]Center Data (Col 2)",
		  'kdmm_data3_col2' => "[K-Dev Mega Menu]Right Data (Col 2)",		  
		  'kdmm_data1_col3' => "[K-Dev Mega Menu]Left Data (Col 3)",
		  'kdmm_data2_col3' => "[K-Dev Mega Menu]Center Data (Col 3)",
		  'kdmm_data3_col3' => "[K-Dev Mega Menu]Right Data (Col 3)",
		  'kdmm_data1_col4' => "[K-Dev Mega Menu]Left Data (Col 4)",
		  'kdmm_data2_col4' => "[K-Dev Mega Menu]Center Data (Col 4)",
		  'kdmm_data3_col4' => "[K-Dev Mega Menu]Right Data (Col 4)",
		  'kdmm_data1_col5' => "[K-Dev Mega Menu]Left Data (Col 5)",
		  'kdmm_data2_col5' => "[K-Dev Mega Menu]Center Data (Col 5)",
		  'kdmm_data3_col5' => "[K-Dev Mega Menu]Right Data (Col 5)",
		  'kdmm_data1_col6' => "[K-Dev Mega Menu]Left Data (Col 6)",
		  'kdmm_data2_col6' => "[K-Dev Mega Menu]Center Data (Col 6)",
		  'kdmm_data3_col6' => "[K-Dev Mega Menu]Right Data (Col 6)",		  
		  'kdmm_data1_col7' => "[K-Dev Mega Menu]Left Data (Col 7)",
		  'kdmm_data2_col7' => "[K-Dev Mega Menu]Center Data (Col 7)",
		  'kdmm_data3_col7' => "[K-Dev Mega Menu]Right Data (Col 7)",
		  'kdmm_data1_col8' => "[K-Dev Mega Menu]Left Data (Col 8)",
		  'kdmm_data2_col8' => "[K-Dev Mega Menu]Center Data (Col 8)",
		  'kdmm_data3_col8' => "[K-Dev Mega Menu]Right Data (Col 8)"
	
	));
}
add_action("wp_head","kdmm_mega_menu_style"); 
function kdmm_mega_menu_style(){
	?>
	<style>
		.kdmm_mega_menu_style{
			display: flex;
			float: right;
			text-align: right;
			
		}
		.kdmm_mega_menu_style li a{
			padding:10px 20px;
			display:block;
			text-decoration:unset;
			color:#000000;
		}
		.kdmm_mega_menu_style li {
			padding:10px 0px;
			position:relative;
			display:block;
		}
		.kdmm_mega_menu_style .sub-menu{
			display:none;
		}
		html .kdmm_mega_menu_style > li:hover > .sub-menu{
			right:0px;
		}
		.kdmm_mega_menu_style li:hover > .sub-menu::before{
			content: "";
			width: 10px;
			height: 10px;
			background: #f7f7f7;
			font-size: 0;
			display: block;
			transform: rotate(52deg);
			position: relative;
			top: -4px;
			left: -20px;
		}
		.kdmm_mega_menu_style li:hover > .sub-menu{
			width: 140px;
			display: block;
			position: absolute;
			top: 50px;
			left: -60px;
			background: #f7f7f7;
            box-shadow: 0px 0px 18px 0px #0000002e;
			z-index:120;
			border-radius:10px;
		}
		
	</style>
	<?php
}
add_action('init','kdmm_register_my_menus');
function kdmm_mega_menu(){
	
	wp_nav_menu(array('theme_location'=>'kdmm_main_menu','menu_class'=>'kdmm_mega_menu_style','menu_id'=>'kdmm_main_menu','container'=>'')); 

}
add_shortcode("kdmm_mega_menu","kdmm_mega_menu");
?>
