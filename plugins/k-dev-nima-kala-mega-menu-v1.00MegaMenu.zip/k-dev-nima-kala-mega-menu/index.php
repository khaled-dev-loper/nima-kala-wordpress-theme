<?php 
/*
Plugin Name:    K-Dev Nima Kala Mega Menu
Description:    create Mega menu , you can use with a little shortcode [kdmm_mega_menu]
Author:         Khaled Developer
Author URI:     https://aparat.com/khaledsss
Version:        1.0
Text Domain:    kdev-mega-menu
Domain Path:    /lang
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/ 
function kdmm_register_my_menus(){
register_nav_menus(
	array('kdmm_main_menu'=> "[K-Dev Mega Menu]Main Menu",
		  'kdmm_mega_menu' => "[K-Dev Mega Menu]Mega Menu"
	));
}
add_action("wp_head","kdmm_mega_menu_style"); 
function kdmm_mega_menu_style(){
	?>
	<style>
		.kdmm_main_menu_style{
			display: flex;
			float: right;
			text-align: right;
		}
		body .kdmm_main_menu_style > li{
			padding-bottom: 13px ;
			transition:0.1s border-bottom;
			border-bottom: solid 3px #ffffff00;
		}
		.kdmm_main_menu_style > li:hover{
			border-bottom: solid 3px #f44336;
		}
		.kdmm_main_menu_style li a{
			padding:10px 20px;
			display:block;
			text-decoration:unset;
			color:#000000;
		}
		.kdmm_main_menu_style li {
			padding:10px 0px;
			position:relative;
			display:block;
		}
		.kdmm_main_menu_style .sub-menu{
			display:none;
		}
		html .kdmm_main_menu_style > li:hover > .sub-menu{
			right:0px;
		}
		.kdmm_main_menu_style li:hover > .sub-menu::before{
			content: "";
			width: 10px;
			height: 10px;
			background: #f7f7f7;
			font-size: 0;
			display: block;
			transform: rotate(52deg);
			position: relative;
			top: -4px;
			left: -20px;
		}
		.kdmm_main_menu_style li:hover > .sub-menu{
			width: 140px;
			display: block;
			position: absolute;
			top: 50px;
			left: -60px;
			background: #f7f7f7;
            box-shadow: 0px 0px 18px 0px #0000002e;
			z-index:120;
			border-radius:10px;
		}
		
	</style>
	<style>
	.kdmm_main_menu_style >li:nth-child(1):hover + .kdmm-space-menu{
		display:block;
	}
	*{
		margin:0;
		padding:0;
	}
	.kdmm-space-menu{
		transition:0.2s all;
		display:none;
		right: 0;
		z-index: 99999;
		top: 140px;
		direction:rtl;
		position: absolute;
		width: 100%;
		height: 100vw;
		background: #00000046;
		background: linear-gradient(180deg, #00000046, transparent);
	}
	.kdmm-mega-menu{
		width: 80%;
		height: 416px;
		max-width: 1200px;
		background: #fff;
		left: 0;
		right: 0;
		margin: auto;
		border-radius: 0 0 5px 5px;
	}
	.kdmm-mega-menu ul, .kdmm-mega-menu li {
		display:block;
	}
	.kdmm-mega-menu > ul {
		background:#f7f7f7;
		height: 100%;
		width: 100%;
		flex-direction: column;
		position: relative;
		align-items: flex-end;
	}
	.kdmm-mega-menu > ul > li{
		margin-right: 4px;
		padding: 14px 8px;
		border-radius: 0 5px 5px 0;
		width:20%
		cursor:pointer;
	}
	.kdmm-mega-menu > ul > li:hover {
		background:#fff;
	}
	.kdmm-mega-menu > ul > li:hover > .sub-menu {
		display:flex;
		flex-wrap: wrap;
	}
	.kdmm-mega-menu > ul > li > .sub-menu{
		width: calc(calc(84% - 14px) - 20px);
		position: absolute;
		display:none;
		left: 0;
		top: 0;
		height: calc(100% - 20px);
		background: #fff;
		padding: 10px;
	}
	.kdmm-mega-menu > ul > li > a {
		padding: 14px 8px;
		color: #616161;
		-webkit-box-align: center;
		-ms-flex-align: center;
		align-items: center;
		cursor: pointer;
		font-size: 12px;
		line-height: 1.833;
		font-weight: 700;
		text-decoration:unset;
	}
	.kdmm-mega-menu >ul>li>ul>li {
		display: -webkit-inline-box;
		display: -ms-inline-flexbox;
		display: inline-flex;
		-webkit-box-orient: vertical;
		-webkit-box-direction: normal;
		-ms-flex-direction: column;
		flex-direction: column;
		-webkit-box-pack: start;
		-ms-flex-pack: start;
		justify-content: flex-start;
		width: 25%;
		font-size: 12px;
		line-height: 30px;
		max-width: 100%;
		overflow: hidden;
		text-overflow: ellipsis;
		vertical-align: middle;
	}
	
	.kdmm-mega-menu a {
		text-decoration: unset;
		color:var(--bs-gray-900);
	}
	.kdmm-mega-menu > ul > li > ul .menu-item-has-children > a, .kdmm-mega-menu > ul > li > ul > li > a {
		color: #d32f2f;
		font-weight: 700;
	}
	.kdmm-mega-menu > ul > li > ul .menu-item-has-children > a::after, .kdmm-mega-menu > ul > li > ul > li > a::after {
		content: " > ";
	}
	@media only screen and (max-width:992px){
		.kdmm-space-menu{
			top:0px;
			padding-top:30px;
		}
	}
	</style>
	<?php
}
add_action('init','kdmm_register_my_menus');
function kdmm_mega_menu(){
	//Desktop
	?>
	<div class='d-none d-sm-none d-md-none d-lg-block'>
		<div class='kdmm-mega-menu-main'>
		<?php wp_nav_menu(array('theme_location'=>'kdmm_main_menu','menu_class'=>'kdmm_main_menu_style','menu_id'=>'kdmm_main_menu','container'=>''));  ?>
			<div class='kdmm-space-menu'>
				<div class='kdmm-mega-menu'>
					<?php wp_nav_menu(array('theme_location'=>'kdmm_mega_menu','menu_class'=>'kdmm_mega_menu_new','menu_id'=>'kdmm_mega_menu','container'=>''));  ?>
				</div>
			</div>
			<script>(function($){
				$(".kdmm-space-menu").fadeOut("fast");
				$(".kdmm-mega-menu").hover(function(){},function(){$(".kdmm-space-menu").fadeOut("fast");});
				$(".kdmm_main_menu_style >li:nth-child(1)").hover(function(){$(".kdmm-space-menu").fadeIn("fast");});
			})(jQuery)</script>
		</div>
	</div>
<?php
}
add_shortcode("kdmm_mega_menu","kdmm_mega_menu");
function kdmm_mega_menu_android(){
	//Mobile

?>
<div class='d-md-block d-sm-block d-lg-none'>
	Mobile Menu
</div>
<?php
}
add_shortcode("kdmm_mega_menu_android","kdmm_mega_menu_android");
?>
