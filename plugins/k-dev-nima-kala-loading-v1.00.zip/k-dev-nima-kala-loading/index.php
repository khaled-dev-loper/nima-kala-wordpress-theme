<?php 
/*
Plugin Name:    K-Dev Nima kala Loading
Description:    Nima Kala Loading
Author:         Khaled Developer
Author URI:     https://aparat.com/khaledsss
Version:        1.0
Text Domain:    kdev-nima-kala-loading
Domain Path:    /lang
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/ 
/** Save Data **/
function kdnk_save($key,$data){
	if(kdnk_get($key,"NULLINIMATEx912039120310239109420892834082309480298340283049") == "NULLINIMATEx912039120310239109420892834082309480298340283049"){
		add_option($key,$data);
	}else{
		update_option($key,$data);
	}
}
function kdnk_get($key,$def = null){
	return get_option($key,$def);
}
function kdnk_delete($key){
	return delete_option($key);
}
/** Save Data [END] **/
function kdnk_menus(){
	/// add Main Menu
	if(menu_page_url('k-dev-nima-kala',false) == null){
		
	}else{}
		add_submenu_page( 
			'k-dev-nima-kala',
			'Loading',
			'Loading',
			'manage_options',
			'k-dev-nima-kala-loading',
			"kdnk_submenu_content"
		); 
	
}
add_action( 'admin_menu', 'kdnk_menus',11 );
function kdnk_defulat_options(){
	kdnk_get("kdnk_is_loading") == null ? kdnk_save("kdnk_is_loading","1") : "";
	kdnk_get("kdnk_circle_count") == null ? kdnk_save("kdnk_circle_count","4") : "";
}
kdnk_defulat_options();
function kdnk_submenu_content(){ 
	echo "<br><br><br>";
	$isLoading = "";
	if(isset($_POST['action']) && $_POST['action']  == 'بازنشانی'){
		echo "<b>بازنشانی شد.</b>";
		kdnk_delete("kdnk_is_loading");
		kdnk_delete("kdnk_circle_count");
		kdnk_defulat_options();
	}else if (isset($_POST['action']) && $_POST['action']  == 'ثبت اطلاعات'){
		///  			Is Loading
		$isLoading = (isset($_POST['isLoading']) ? $_POST['isLoading'] == "on" : "0");
		kdnk_save("kdnk_is_loading",strval(intval($isLoading)));
		echo "<b>ثبت شد.</b>";
		///				Circle Count
		$CircleCount = (isset($_POST['CircleCount']) ? $_POST['CircleCount'] : "4");
		kdnk_save("kdnk_circle_count",$CircleCount);
	}
?>
	
	<form method='post' >
		<label>لودینگ نمایش داده شود:</label>
		<input type='checkbox' name='isLoading' <?php echo (kdnk_get("kdnk_is_loading") == "1" )? "checked" : "";   ?> />
		<br>
		<label> تعداد دایره های روی لودینگ: </label>
		<input type='number' min='0' max='12' name='CircleCount' value="<?php echo (kdnk_get("kdnk_circle_count") != null ? kdnk_get("kdnk_circle_count") : "4");   ?>" />
		<br>
		<br>
		<input type='submit' name='action' class='button-primary' value='ثبت اطلاعات' />
		<input type='submit' name='action' class='button' value='بازنشانی' />
	<form>
	
	
	
<?php }

add_action("wp_head","kdnk_style_loading_bar");
function kdnk_style_loading_bar(){
	if(kdnk_get("kdnk_is_loading") == "1"):
	?>
	
	<script name='kdnk-loading-bar' type='text/javascript' >
		window.addEventListener("load",function(){
			var kdnk_loading_bar = document.getElementById("kdnk-loading-bar");
			// Create Element.remove() function if not exist
			kdnk_loading_bar.remove();
		});
	</script>
	<style name='kdnk-loading-bar'>
			.kdnk-loading-panel{
			    width: 100vw;
				height: 100vh;
				background: #00000040;
				position:fixed;
				z-index: 9999;
			}
			.kdnk-loading-panel .kdnk-loading-box {
				width: 250px;
				height: 140px;
				background: white;
				border: solid .5px #bbbbbb;
				margin: auto;
				position: relative;
				top: calc(calc(100vh - 140px) / 2);
				box-shadow: 0px 0px 20px 0px #00000038;
			}
			.kdnk-loading-panel .kdnk-loading-box .kdnk-img {
				height: 60%;
				width:100%;
				position: relative;
			}
			.kdnk-loading-panel .kdnk-loading-box .kdnk-img img{
			    width: 106px;
				margin: auto;
				display: block;
				vertical-align: middle;
				position: relative;
				top: 20%;
			}
			.kdnk-loading-panel .kdnk-loading-box .kdnk-loading-anim {
				position:relative;
				height:40%;
				width:100%;
			    display: flex;
				justify-content: center;
				align-items: center;
			}
			.kdnk-anima {
				width: 12px;
				height: 12px;
				background: #f44336;
				border-radius: 100%;
				margin: 0px 5px;
				animation-name:kdnk_loading_anim;
			    animation-duration: 1s;
				animation-iteration-count: infinite;
				animation-timing-function: ease-out;
				position:relative;
			}
			<?php if(intval(kdnk_get("kdnk_circle_count")) >= 1){  ?>
			.kdnk-anim-1{
				animation-delay:0s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 2){  ?>
			.kdnk-anim-2{
				animation-delay:0.2s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 3){  ?>
			.kdnk-anim-3{
				animation-delay:0.4s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 4){  ?>
			.kdnk-anim-4{
				animation-delay:0.6s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 5){  ?>
			.kdnk-anim-5{
				animation-delay:0.8s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 6){  ?>
			.kdnk-anim-6{
				animation-delay:1s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 7){  ?>
			.kdnk-anim-7{
				animation-delay:1.2s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 8){  ?>
			.kdnk-anim-8{
				animation-delay:1.4s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 9){  ?>
			.kdnk-anim-9{
				animation-delay:1.6s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 10){  ?>
			.kdnk-anim-10{
				animation-delay:1.8s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 11){  ?>
			.kdnk-anim-11{
				animation-delay:2s;
			}
			<?php } if(intval(kdnk_get("kdnk_circle_count")) >= 12){  ?>
			.kdnk-anim-12{
				animation-delay:2.2s;
			}
			<?php } ?>
			@keyframes kdnk_loading_anim {
				0%{
					top:0;
					filter:opacity(100%);
				}50%{
					top:-10px;
					filter:opacity(50%);
				}100%{
					top:0;
					filter:opacity(100%);
				}
			}
	</style><?php endif;
}
function kdnk_loading_bar($atts){
	if(kdnk_get("kdnk_is_loading") == "1"){
		$atts = shortcode_atts( array(
			'logo' => 'NULL',
			'count' => '4'
		), $atts, 'bartag' );
		$count = intval($atts['count']);
		$kdnk_animas = "";
		for($i = 1;$i <= $count;$i++){
			$kdnk_animas .= "<div class='kdnk-anima kdnk-anim-$i'></div>";
		}
		$logo = $atts['logo'];
		return "
			<div class='kdnk-loading-panel' id='kdnk-loading-bar'>
				<div class='kdnk-loading-box'>
					<div class='kdnk-img'>
						<img src='$logo' alt='loading'  loading='lazy' />
					</div>
					<div class='kdnk-loading-anim'>
						$kdnk_animas
					</div>
				</div>	
			</div>
		";
	}else{
		return "";
	}
}
add_shortcode("kdnk_loading_bar","kdnk_loading_bar");
?>
