<?php 
/*
Plugin Name:    K-Dev Nima Kala Baby SEO
Description:    Baby SEO for Nima Kala Theme[kdmm_mega_menu]
Author:         Khaled Developer
Author URI:     https://aparat.com/khaledsss
Version:        1.0
Text Domain:    kdev-baby-seo
Domain Path:    /lang
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/ 
function kdnkbs_seo(){
	return "
		<meta name='title' content='<?php echo bloginfo( 'name' ).wp_title(); ?>' />
		<link rel=\"canonical\" href=\"<?php echo home_url();  ?>\">
		<meta name=\"description\" content=\"<?php echo bloginfo('description'); ?>\">
	";
}
add_shortcode("kdnkbs_seo","kdnkbs_seo");
?>